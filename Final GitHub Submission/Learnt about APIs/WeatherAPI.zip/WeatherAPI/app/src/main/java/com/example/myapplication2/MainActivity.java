package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import android.widget.Toast;


import java.util.List;

public class MainActivity extends AppCompatActivity {

//    ProgressDialog progressDialog;
    Button displayData;
    String input;
    EditText cityinput;
    ListView lv;

     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayData = (Button) findViewById(R.id.displayData);
        cityinput = (EditText) findViewById(R.id.plainText);
        lv = (ListView) findViewById(R.id.listView);

        final WeatherDataService weatherDataService = new WeatherDataService(MainActivity.this);


        displayData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input = cityinput.getText().toString().toLowerCase();

                input = weatherDataService.getCityId(input, new WeatherDataService.VolleyResponseListener() {
                    @Override
                    public void OnError(String message) {
                        Toast.makeText(MainActivity.this, "Error!!!", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void OnResponse(String cityId) {

                        weatherDataService.getCityForecastById(cityId, new WeatherDataService.ForecastByIdResponse() {
                            @Override
                            public void OnError(String message) {
                                Toast.makeText(MainActivity.this, "Something Wrong here!", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void OnResponse(List<WeatherReportModel> weatherReportModels) {

                                ArrayAdapter arrayAdapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, weatherReportModels);

                                lv.setAdapter(arrayAdapter);

                            }
                        });
                    }
                });



                // Instantiate the RequestQueue.
                //RequestQueue queue = Volley.newRequestQueue(MainActivity.this);

            }
        });
    }

}

///Last Program stuff


//        displayData = (Button) findViewById(R.id.fetchsudokubtn);
//        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
//
//        displayData.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//
//                    try {
//                        output = geturl();
//                    } catch (Exception e) {
//                        Toast.makeText(MainActivity.this, "PLEASE SELECT ONE", Toast.LENGTH_SHORT).show();
//                    }
//
//                Toast.makeText(MainActivity.this, output, Toast.LENGTH_SHORT).show();
//                output= "https://www.metaweather.com/api/location/search/?query=london";
//
//                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
//                String url = output;
//
//                JsonArrayRequest jsonArrayRequest = new JsonArrayRequest
//                        (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
//
//                            @Override
//                            public void onResponse(JSONArray response) {
//                                Toast.makeText(MainActivity.this, response.toString(), Toast.LENGTH_SHORT).show();
//                            }
//                        }, new Response.ErrorListener() {
//
//                            @Override
//                            public void onErrorResponse(VolleyError error) {
//                                Toast.makeText(MainActivity.this, "ERRORRRRR", Toast.LENGTH_SHORT).show();
//
//                            }
//                        });
//
//
//                queue.add(jsonArrayRequest);

//                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, input,null, response -> {
//
//                        Toast.makeText(MainActivity.this, "SOMETHING", Toast.LENGTH_SHORT).show();
//
//                }, error -> Toast.makeText(MainActivity.this, "ERROoooooRR", Toast.LENGTH_SHORT).show());
//
//                queue.add(request);

// Request a string response from the provided URL.
//                StringRequest stringRequest = new StringRequest(Request.Method.GET, output,
//
//                        response -> Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show(),
//                        error -> Toast.makeText(MainActivity.this, "ERRORRRRR", Toast.LENGTH_SHORT).show());
//
//                            // Add the request to the RequestQueue.
//                queue.add(stringRequest);





//    }
//
//    public String geturl(){
//
//        int radioId = radioGroup.getCheckedRadioButtonId();
//        String output;
//        radioButton = findViewById(radioId);
//
//        if (radioButton.getText().toString().equals("Easy")) {
//            output = input + 1;
//        } else if (radioButton.getText().toString().equals("Medium")) {
//            output = input + 2;
//        } else if (radioButton.getText().toString().equals("Hard")) {
//            output = input + 3;
//        } else {
//            output = "ERROR";
//        }
//        return output;
//    }
//


//        RequestQueue queue = Volley.newRequestQueue(this);
//        String url ="http://www.cs.utep.edu/cheon/ws/sudoku/new/?size=9&level="+input;
//
//
//        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//
//
//
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//
//
//            }
//        });

// Add the request to the RequestQueue.
//        queue.add(stringRequest);
