package com.example.myapplication2;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class WeatherDataService {


    public static final String QUERY_FOR_CITY_ID = "https://www.metaweather.com/api/location/search/?query=";
    public static final String QUERY_FOR_CITY_WEATHER_BY_ID = "https://www.metaweather.com/api/location/";

    Context context;
    String cityId = "";
    public WeatherDataService(Context context) {
        this.context = context;
    }

    public interface VolleyResponseListener{
        void OnError(String message);

        void OnResponse(String cityId);

    }

    public String getCityId(String cityName, VolleyResponseListener volleyResponseListener){


        String url = QUERY_FOR_CITY_ID +cityName;

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                try {
                    JSONObject cityinfo = response.getJSONObject(0);
                    cityId = cityinfo.getString("woeid");

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                //Toast.makeText(context, "CityId is " + cityId, Toast.LENGTH_SHORT).show();
                volleyResponseListener.OnResponse(cityId);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(context, "Error!!!", Toast.LENGTH_SHORT).show();
                volleyResponseListener.OnError("Error!!@");
            }
        });

//
//                // Request a string response from the provided URL.
//                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
//                        new Response.Listener<String>() {
//                            @Override
//                            public void onResponse(String response) {
//                                // Display the first 500 characters of the response string.
//                                Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();
//                            }
//                        }, new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(MainActivity.this, "Error!!", Toast.LENGTH_SHORT).show();
//                    }
//                });
//
//                // Add the request to the RequestQueue.
//                queue.add(request);
        MySingleton.getInstance(context).addToRequestQueue(request);
        return cityId;
        //input=resultsTextView.getText().toString();
        //Toast.makeText(MainActivity.this, "You typed"+input, Toast.LENGTH_SHORT).show();

    }

    public interface ForecastByIdResponse{
        void OnError(String message);

        void OnResponse(List <WeatherReportModel> weatherReportModels);

    }

    public void getCityForecastById(String cityId, ForecastByIdResponse forecastByIdResponse) {
        String url = QUERY_FOR_CITY_WEATHER_BY_ID + cityId;

        List<WeatherReportModel> report = new ArrayList<>();
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                //Toast.makeText(context, response.toString(), Toast.LENGTH_SHORT).show();
                try {
                    JSONArray consolidated_weather_list = response.getJSONArray("consolidated_weather");

                    for(int i=0; i<consolidated_weather_list.length(); i++) {

                        WeatherReportModel one_day_weather = new WeatherReportModel();
                        JSONObject first_day_from_api = (JSONObject) consolidated_weather_list.get(i);

                        one_day_weather.setId(first_day_from_api.getInt("id"));
                        one_day_weather.setWeather_state_name(first_day_from_api.getString("weather_state_name"));
                        one_day_weather.setWeather_state_abbr(first_day_from_api.getString("weather_state_name"));
                        one_day_weather.setWind_direction_compass(first_day_from_api.getString("wind_direction_compass"));
                        one_day_weather.setCreated(first_day_from_api.getString("created"));
                        one_day_weather.setApplicable_date(first_day_from_api.getString("applicable_date"));
                        one_day_weather.setMin_temp((float) first_day_from_api.getDouble("min_temp"));
                        one_day_weather.setMax_temp((float) first_day_from_api.getDouble("max_temp"));
                        one_day_weather.setThe_temp((float) first_day_from_api.getDouble("the_temp"));
                        one_day_weather.setWind_speed((float) first_day_from_api.getDouble("wind_speed"));
                        one_day_weather.setWind_direction((float) first_day_from_api.getDouble("wind_direction"));
                        one_day_weather.setAir_pressure(first_day_from_api.getInt("air_pressure"));
                        one_day_weather.setHumidity(first_day_from_api.getInt("humidity"));
                        one_day_weather.setPredictability(first_day_from_api.getInt("predictability"));
                        one_day_weather.setVisibility((float) first_day_from_api.getDouble("visibility"));

                        report.add(one_day_weather);
                    }

                    forecastByIdResponse.OnResponse(report);



                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Galat ho gaya hai", Toast.LENGTH_SHORT).show();
            }
        });
        MySingleton.getInstance(context).addToRequestQueue(request);
    }

}
//    public List<WeatherReportModel> getCityForecastByName(String cityName){
//
//    }