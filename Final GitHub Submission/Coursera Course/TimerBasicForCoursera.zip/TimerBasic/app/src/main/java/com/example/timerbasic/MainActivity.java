package com.example.timerbasic;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    TextView clockTextView;
    Button startStopButton;
    boolean timerstarted = false;
    Timer timer;
    TimerTask timertask;
    Double time=0.0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         clockTextView = (TextView) findViewById(R.id.clockTextView);
         startStopButton = (Button) findViewById(R.id.startStopButton);

         timer= new Timer();

    }

    public void startStopTapped(View view) {

        if(timerstarted){
            startStopButton.setText("START");
            timerstarted= false;
            timertask.cancel();
        }
        else{
            startStopButton.setText("STOP");
            timerstarted= true;
            startTimer();
        }
    }

    private void startTimer() {
        timertask= new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        time++;
                        clockTextView.setText(getTimer());
                    }
                });
            }
        };
        timer.scheduleAtFixedRate(timertask, 0,10);
    }

    private String getTimer() {
        int initial= (int) Math.round(time);
        int rounded = initial/100;
        int milliseconds = (initial%100);

        int seconds = ((rounded%86400)%3600)%60;
        int minutes = ((rounded%86400)%3600)/60;
        int hours = ((rounded%86400)/3600);

        return formattime(seconds, minutes, milliseconds);

    }

    private String formattime(int seconds, int minutes, int milliseconds) {

        return String.format("%02d", minutes)+ " : "+String.format("%02d", seconds)+ " : "+String.format("%02d", milliseconds);
    }


    public void resetTapped(View view) {
        AlertDialog.Builder resetalert = new AlertDialog.Builder(this);
        resetalert.setTitle("Reset?");
        resetalert.setPositiveButton("Yes!!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(timertask!=null){
                    timertask.cancel();
                    time=0.0;
                    timerstarted=false;
                    startStopButton.setText("START");
                    clockTextView.setText(formattime(0,0,0));
                }
            }
        });

        resetalert.setNeutralButton("No!!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        resetalert.show();
    }
}